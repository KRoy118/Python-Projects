# B2B Invoice Prediction System
The project was to make an automated invoice payment date prediction web app. The dates were generated using ML.
The generated resultset(.csv) was stored as a JSON file from sql database,then connected using java backend.
Further ui was made using html,css and javascript.

