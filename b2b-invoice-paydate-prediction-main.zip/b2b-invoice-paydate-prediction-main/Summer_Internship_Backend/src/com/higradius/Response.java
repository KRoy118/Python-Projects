package com.higradius;
public class Response {
	  String custno;
	  String custname;
	   String amount;
	   String  invoiceid;
	   String  duedate;
	   String  paydate;
	  
	  
	    
	     public String getCustno() {
	          return custno;
	     }
	     public void setCustno(String custno) {
	          this.custno =custno;
	     }
	     
	     
	     public String getCustname() {
	          return custname;
	     }
	     public void setCustname(String custname) {
	          this.custname = custname;
	     }
	     
	     
	     public String getAmount() {
	          return amount;
	     }
	     public void setAmount(String  amount) {
	          this.amount = amount;
	     }
	     
	     
	     
	     public String  getInvoiceid() {
	          return invoiceid;
	     }
	     public void setInvoiceid(String  invoiceid) {
	          this.invoiceid = invoiceid;
	     }
	     
	     
	     public String  getPaydate() {
	          return paydate;
	     }
	     public void setPaydate(String  paydate) {
	          this.paydate = paydate;
	     }
	     
	     
	     public String  getDuedate() {
	          return paydate;
	     }
	     public void setDuedate(String  duedate) {
	          this.duedate = duedate;
	     }
	     
	     
	}




















